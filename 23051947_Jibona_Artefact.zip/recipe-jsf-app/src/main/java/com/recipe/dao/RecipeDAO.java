package com.recipe.dao;

import com.recipe.model.Recipe;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the RECIPE table.
 * Supports listing all recipes, searching by keyword, fetching by ID, and inserting new recipes.
 */
public class RecipeDAO {

    /** Returns all recipes ordered by newest first. */
    public List<Recipe> getAllRecipes() {
        return searchRecipes("");
    }

    /**
     * Returns recipes whose title or description contains the given query string.
     * Case-insensitive. Passing an empty string returns all recipes.
     */
    public List<Recipe> searchRecipes(String query) {
        List<Recipe> list = new ArrayList<>();
        String sql = "SELECT r.recipe_id, r.title, r.description, r.prep_minutes, " +
                     "       r.cook_minutes, r.servings, r.difficulty, r.chef_id, " +
                     "       r.created_at, c.display_name AS chef_name " +
                     "FROM   recipe r " +
                     "JOIN   chef   c ON r.chef_id = c.chef_id " +
                     "WHERE  UPPER(r.title)       LIKE UPPER(?) " +
                     "OR     UPPER(r.description) LIKE UPPER(?) " +
                     "ORDER  BY r.created_at DESC";

        String like = "%" + query + "%";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, like);
            ps.setString(2, like);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Fetches a single recipe by its primary key (ingredients NOT loaded here;
     * use IngredientDAO.getByRecipeId to load them separately).
     */
    public Recipe getRecipeById(int recipeId) {
        String sql = "SELECT r.recipe_id, r.title, r.description, r.prep_minutes, " +
                     "       r.cook_minutes, r.servings, r.difficulty, r.chef_id, " +
                     "       r.created_at, c.display_name AS chef_name " +
                     "FROM   recipe r " +
                     "JOIN   chef   c ON r.chef_id = c.chef_id " +
                     "WHERE  r.recipe_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, recipeId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Inserts a new recipe row.
     * On success the generated recipe_id is set back on the passed Recipe object.
     * Returns true if the insert succeeded.
     */
    public boolean addRecipe(Recipe recipe) {
        String sql = "INSERT INTO recipe " +
                     "(title, description, prep_minutes, cook_minutes, servings, difficulty, chef_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, recipe.getTitle());
            ps.setString(2, recipe.getDescription());
            ps.setInt   (3, recipe.getPrepMinutes());
            ps.setInt   (4, recipe.getCookMinutes());
            ps.setInt   (5, recipe.getServings());
            ps.setString(6, recipe.getDifficulty());
            ps.setInt   (7, recipe.getChefId());

            if (ps.executeUpdate() > 0) {
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) {
                    recipe.setRecipeId(keys.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /** Returns recipes that have the given tag. */
    public List<Recipe> getRecipesByTagId(int tagId) {
        List<Recipe> list = new ArrayList<>();
        String sql = "SELECT r.recipe_id, r.title, r.description, r.prep_minutes, " +
                     "       r.cook_minutes, r.servings, r.difficulty, r.chef_id, " +
                     "       r.created_at, c.display_name AS chef_name " +
                     "FROM   recipe r " +
                     "JOIN   chef c ON r.chef_id = c.chef_id " +
                     "JOIN   recipe_tag rt ON r.recipe_id = rt.recipe_id " +
                     "WHERE  rt.tag_id = ? ORDER BY r.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, tagId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Updates the main fields of an existing recipe.
     * Ingredients are handled separately by IngredientDAO.
     */
    public boolean updateRecipe(Recipe recipe) {
        String sql = "UPDATE recipe SET title=?, description=?, " +
                     "prep_minutes=?, cook_minutes=?, servings=?, difficulty=? " +
                     "WHERE recipe_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, recipe.getTitle());
            ps.setString(2, recipe.getDescription());
            ps.setInt   (3, recipe.getPrepMinutes());
            ps.setInt   (4, recipe.getCookMinutes());
            ps.setInt   (5, recipe.getServings());
            ps.setString(6, recipe.getDifficulty());
            ps.setInt   (7, recipe.getRecipeId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Deletes a recipe owned by the given chef (ownership check).
     */
    public boolean deleteRecipe(int recipeId, int chefId) {
        String sql = "DELETE FROM recipe WHERE recipe_id = ? AND chef_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, recipeId);
            ps.setInt(2, chefId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Deletes any recipe by ID regardless of owner – admin use only.
     * Ingredients are removed automatically via ON DELETE CASCADE.
     */
    public boolean deleteRecipeById(int recipeId) {
        String sql = "DELETE FROM recipe WHERE recipe_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, recipeId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ---------------------------------------------------------------

    private Recipe mapRow(ResultSet rs) throws SQLException {
        Recipe r = new Recipe();
        r.setRecipeId   (rs.getInt      ("recipe_id"));
        r.setTitle      (rs.getString   ("title"));
        r.setDescription(rs.getString   ("description"));
        r.setPrepMinutes(rs.getInt      ("prep_minutes"));
        r.setCookMinutes(rs.getInt      ("cook_minutes"));
        r.setServings   (rs.getInt      ("servings"));
        r.setDifficulty (rs.getString   ("difficulty"));
        r.setChefId     (rs.getInt      ("chef_id"));
        r.setChefName   (rs.getString   ("chef_name"));
        r.setCreatedAt  (rs.getTimestamp("created_at"));
        return r;
    }
}

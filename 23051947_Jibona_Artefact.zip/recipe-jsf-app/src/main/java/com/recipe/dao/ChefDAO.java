package com.recipe.dao;

import com.recipe.model.Chef;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the CHEF table.
 * Handles registration, login validation, and duplicate-username checks.
 *
 * Passwords are stored as SHA-256 hex digests (never plain text).
 */
public class ChefDAO {

    // ---------------------------------------------------------------
    // Public API
    // ---------------------------------------------------------------

    /**
     * Returns the matching Chef if the username/password combination is valid,
     * or null if the credentials are wrong.
     */
    public Chef findByCredentials(String username, String password) {
        String sql = "SELECT * FROM chef WHERE username = ? AND password_hash = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, hashPassword(password));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /** Returns every chef row – used by the admin panel. */
    public List<Chef> getAllChefs() {
        List<Chef> list = new ArrayList<>();
        String sql = "SELECT * FROM chef ORDER BY chef_id";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /** Returns true if the given username is already taken. */
    public boolean usernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM chef WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /** Inserts a new chef into the database. Returns true on success. */
    public boolean register(String username, String password,
                            String displayName, String email) {
        String sql = "INSERT INTO chef (username, password_hash, display_name, email) " +
                     "VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, hashPassword(password));
            ps.setString(3, displayName);
            ps.setString(4, email);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // ---------------------------------------------------------------
    // Helpers (package-visible so DBInitializer can reuse hashPassword)
    // ---------------------------------------------------------------

    /** Hashes a plain-text password using SHA-256 → lowercase hex string. */
    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder(64);
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 unavailable", e);
        }
    }

    private Chef mapRow(ResultSet rs) throws SQLException {
        Chef c = new Chef();
        c.setChefId(rs.getInt("chef_id"));
        c.setUsername(rs.getString("username"));
        c.setPasswordHash(rs.getString("password_hash"));
        c.setDisplayName(rs.getString("display_name"));
        c.setEmail(rs.getString("email"));
        return c;
    }
}

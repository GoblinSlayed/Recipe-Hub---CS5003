package com.recipe.dao;

import com.recipe.model.Tag;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the CUISINE_TAG and RECIPE_TAG tables.
 */
public class TagDAO {

    /** Returns all available cuisine tags. */
    public List<Tag> getAllTags() {
        List<Tag> list = new ArrayList<>();
        String sql = "SELECT * FROM cuisine_tag ORDER BY tag_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Tag(rs.getInt("tag_id"), rs.getString("tag_name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /** Returns all tags associated with a given recipe. */
    public List<Tag> getTagsByRecipeId(int recipeId) {
        List<Tag> list = new ArrayList<>();
        String sql = "SELECT ct.tag_id, ct.tag_name " +
                     "FROM cuisine_tag ct " +
                     "JOIN recipe_tag rt ON ct.tag_id = rt.tag_id " +
                     "WHERE rt.recipe_id = ? ORDER BY ct.tag_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, recipeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Tag(rs.getInt("tag_id"), rs.getString("tag_name")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Replaces all tags for a recipe.
     * Deletes existing recipe_tag rows then inserts the new selection.
     * tagIds is a list of tag ID strings (from h:selectManyCheckbox).
     */
    public void setTagsForRecipe(int recipeId, List<String> tagIds) {
        String delete = "DELETE FROM recipe_tag WHERE recipe_id = ?";
        String insert = "INSERT INTO recipe_tag (recipe_id, tag_id) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection()) {
            // Delete existing tags for this recipe
            try (PreparedStatement ps = conn.prepareStatement(delete)) {
                ps.setInt(1, recipeId);
                ps.executeUpdate();
            }
            // Insert new selections
            if (tagIds != null && !tagIds.isEmpty()) {
                try (PreparedStatement ps = conn.prepareStatement(insert)) {
                    for (String tagIdStr : tagIds) {
                        try {
                            int tagId = Integer.parseInt(tagIdStr.trim());
                            ps.setInt(1, recipeId);
                            ps.setInt(2, tagId);
                            ps.addBatch();
                        } catch (NumberFormatException ignored) {}
                    }
                    ps.executeBatch();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

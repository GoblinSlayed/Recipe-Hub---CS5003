package com.recipe.dao;

import com.recipe.model.Ingredient;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the INGREDIENT table.
 */
public class IngredientDAO {

    /** Returns all ingredients for the given recipe, ordered by insertion. */
    public List<Ingredient> getByRecipeId(int recipeId) {
        List<Ingredient> list = new ArrayList<>();
        String sql = "SELECT * FROM ingredient WHERE recipe_id = ? ORDER BY ingredient_id";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, recipeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /** Inserts a single ingredient row. Returns true on success. */
    public boolean addIngredient(Ingredient ing) {
        String sql = "INSERT INTO ingredient (recipe_id, item_name, quantity, unit) " +
                     "VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt   (1, ing.getRecipeId());
            ps.setString(2, ing.getItemName());
            ps.setString(3, ing.getQuantity());
            ps.setString(4, ing.getUnit());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Deletes all ingredients belonging to a recipe.
     * Called before deleting the recipe itself (foreign-key safety).
     */
    public void deleteByRecipeId(int recipeId) {
        String sql = "DELETE FROM ingredient WHERE recipe_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, recipeId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------------

    private Ingredient mapRow(ResultSet rs) throws SQLException {
        Ingredient i = new Ingredient();
        i.setIngredientId(rs.getInt   ("ingredient_id"));
        i.setRecipeId    (rs.getInt   ("recipe_id"));
        i.setItemName    (rs.getString("item_name"));
        i.setQuantity    (rs.getString("quantity"));
        i.setUnit        (rs.getString("unit"));
        return i;
    }
}

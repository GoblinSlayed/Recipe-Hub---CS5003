package com.recipe.dao;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Provides JDBC connections to the embedded Apache Derby database.
 *
 * Derby 10.15.2.0 (from GlassFish javadb) is bundled in WEB-INF/lib.
 * The database is stored at ~/recipe_jsf_db and created automatically.
 */
public class DBConnection {

    private static final String DB_URL =
            "jdbc:derby:" + System.getProperty("com.sun.aas.instanceRoot") + "/recipe_jsf_db;create=true";


    // Loaded via reflection so no compile-time dependency on derby.jar is needed.
    // The JAR is present in WEB-INF/lib at runtime via the Maven dependency.
    private static final java.sql.Driver DRIVER;

    static {
        try {
            Class<?> cls = Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            DRIVER = (java.sql.Driver) cls.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            throw new RuntimeException("Cannot load Derby EmbeddedDriver", e);
        }
    }

    /** Returns a new JDBC connection (caller must close it). */
    public static Connection getConnection() throws SQLException {
        return DRIVER.connect(DB_URL, new java.util.Properties());
    }

    /** Used by DBInitializer shutdown hook. */
    public static java.sql.Driver getDriver() { return DRIVER; }
}

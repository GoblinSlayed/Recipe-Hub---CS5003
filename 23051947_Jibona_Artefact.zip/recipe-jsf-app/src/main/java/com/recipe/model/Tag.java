package com.recipe.model;

import java.io.Serializable;

/**
 * Represents a cuisine tag (e.g. "Italian", "Vegan") that can be attached to recipes.
 */
public class Tag implements Serializable {

    private static final long serialVersionUID = 1L;

    private int    tagId;
    private String tagName;

    public Tag() {}

    public Tag(int tagId, String tagName) {
        this.tagId   = tagId;
        this.tagName = tagName;
    }

    // ---------- Getters & Setters ----------

    public int    getTagId()          { return tagId; }
    public void   setTagId(int v)     { this.tagId = v; }

    public String getTagName()        { return tagName; }
    public void   setTagName(String v){ this.tagName = v; }
}

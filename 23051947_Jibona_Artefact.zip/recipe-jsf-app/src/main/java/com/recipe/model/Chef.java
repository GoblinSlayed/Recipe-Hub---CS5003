package com.recipe.model;

import java.io.Serializable;

/**
 * Represents a registered chef (user) in the system.
 * This is a plain Java Bean (POJO) used to transfer data from the DB to the UI.
 */
public class Chef implements Serializable {

    private static final long serialVersionUID = 1L;

    private int    chefId;
    private String username;
    private String passwordHash;
    private String displayName;
    private String email;

    public Chef() {}

    public Chef(int chefId, String username, String passwordHash,
                String displayName, String email) {
        this.chefId       = chefId;
        this.username     = username;
        this.passwordHash = passwordHash;
        this.displayName  = displayName;
        this.email        = email;
    }

    // ---------- Getters & Setters ----------

    public int    getChefId()       { return chefId; }
    public void   setChefId(int v)  { this.chefId = v; }

    public String getUsername()          { return username; }
    public void   setUsername(String v)  { this.username = v; }

    public String getPasswordHash()         { return passwordHash; }
    public void   setPasswordHash(String v) { this.passwordHash = v; }

    public String getDisplayName()          { return displayName; }
    public void   setDisplayName(String v)  { this.displayName = v; }

    public String getEmail()         { return email; }
    public void   setEmail(String v) { this.email = v; }
}

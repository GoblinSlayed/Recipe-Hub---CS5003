package com.recipe.model;

import java.io.Serializable;

/**
 * Represents a single ingredient line belonging to a Recipe.
 */
public class Ingredient implements Serializable {

    private static final long serialVersionUID = 1L;

    private int    ingredientId;
    private int    recipeId;
    private String itemName;
    private String quantity;
    private String unit;

    public Ingredient() {}

    public Ingredient(int ingredientId, int recipeId,
                      String itemName, String quantity, String unit) {
        this.ingredientId = ingredientId;
        this.recipeId     = recipeId;
        this.itemName     = itemName;
        this.quantity     = quantity;
        this.unit         = unit;
    }

    // ---------- Getters & Setters ----------

    public int    getIngredientId()         { return ingredientId; }
    public void   setIngredientId(int v)    { this.ingredientId = v; }

    public int    getRecipeId()             { return recipeId; }
    public void   setRecipeId(int v)        { this.recipeId = v; }

    public String getItemName()             { return itemName; }
    public void   setItemName(String v)     { this.itemName = v; }

    public String getQuantity()             { return quantity; }
    public void   setQuantity(String v)     { this.quantity = v; }

    public String getUnit()                 { return unit; }
    public void   setUnit(String v)         { this.unit = v; }
}

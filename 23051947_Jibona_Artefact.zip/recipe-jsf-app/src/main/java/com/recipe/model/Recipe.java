package com.recipe.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a recipe stored in the database.
 * Contains a list of Ingredient objects (loaded separately by IngredientDAO).
 */
public class Recipe implements Serializable {

    private static final long serialVersionUID = 1L;

    private int       recipeId;
    private String    title;
    private String    description;
    private int       prepMinutes;
    private int       cookMinutes;
    private int       servings;
    private String    difficulty;   // "easy" | "medium" | "hard"
    private int       chefId;
    private String    chefName;     // joined from chef table
    private Timestamp createdAt;
    private List<Ingredient> ingredients = new ArrayList<>();

    public Recipe() {}

    // ---------- Computed Property ----------

    /** Total cooking time used on the detail page. */
    public int getTotalMinutes() {
        return prepMinutes + cookMinutes;
    }

    // ---------- Getters & Setters ----------

    public int       getRecipeId()        { return recipeId; }
    public void      setRecipeId(int v)   { this.recipeId = v; }

    public String    getTitle()           { return title; }
    public void      setTitle(String v)   { this.title = v; }

    public String    getDescription()         { return description; }
    public void      setDescription(String v) { this.description = v; }

    public int       getPrepMinutes()         { return prepMinutes; }
    public void      setPrepMinutes(int v)    { this.prepMinutes = v; }

    public int       getCookMinutes()         { return cookMinutes; }
    public void      setCookMinutes(int v)    { this.cookMinutes = v; }

    public int       getServings()            { return servings; }
    public void      setServings(int v)       { this.servings = v; }

    public String    getDifficulty()          { return difficulty; }
    public void      setDifficulty(String v)  { this.difficulty = v; }

    public int       getChefId()              { return chefId; }
    public void      setChefId(int v)         { this.chefId = v; }

    public String    getChefName()            { return chefName; }
    public void      setChefName(String v)    { this.chefName = v; }

    public Timestamp getCreatedAt()           { return createdAt; }
    public void      setCreatedAt(Timestamp v){ this.createdAt = v; }

    public List<Ingredient> getIngredients()               { return ingredients; }
    public void             setIngredients(List<Ingredient> v) { this.ingredients = v; }
}

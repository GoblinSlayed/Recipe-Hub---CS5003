package com.recipe.init;

import com.recipe.dao.ChefDAO;
import com.recipe.dao.DBConnection;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.sql.*;

/**
 * Runs once when the web application starts.
 *
 * Responsibilities:
 *  1. Create all five database tables if they do not already exist.
 *  2. Insert one demo chef (admin / admin123) and three sample recipes
 *     if the database is empty.
 *  3. Shut down the embedded Derby engine cleanly when the app stops.
 *
 * @WebListener registers this class automatically; no web.xml entry needed.
 */
@WebListener
public class DBInitializer implements ServletContextListener {

    // ---------------------------------------------------------------
    // Lifecycle callbacks
    // ---------------------------------------------------------------

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("[DBInitializer] Initialising RecipeHub database...");
        try (Connection conn = DBConnection.getConnection()) {
            createTables(conn);
            seedSampleData(conn);
            System.out.println("[DBInitializer] Database ready.");
        } catch (SQLException e) {
            System.err.println("[DBInitializer] ERROR during initialisation:");
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        // Shut down embedded Derby cleanly to release file locks
        // This is essential before redeployment to avoid XSDB6 errors
        try {
            DBConnection.getDriver().connect(
                "jdbc:derby:;shutdown=true", new java.util.Properties());
        } catch (SQLException e) {
            // SQLState XJ015 = Derby system shutdown - expected, NOT an error
            if (!"XJ015".equals(e.getSQLState())) {
                e.printStackTrace();
            }
        }
        System.out.println("[DBInitializer] Derby engine shut down cleanly.");
    }

    // ---------------------------------------------------------------
    // Table creation
    // ---------------------------------------------------------------

    private void createTables(Connection conn) throws SQLException {
        // chef -------------------------------------------------------
        createTableIfAbsent(conn, "chef",
            "CREATE TABLE chef (" +
            "  chef_id      INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, " +
            "  username     VARCHAR(50)  NOT NULL UNIQUE, " +
            "  password_hash VARCHAR(64) NOT NULL, " +
            "  display_name VARCHAR(100), " +
            "  email        VARCHAR(100) " +
            ")");

        // recipe -----------------------------------------------------
        createTableIfAbsent(conn, "recipe",
            "CREATE TABLE recipe (" +
            "  recipe_id    INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, " +
            "  title        VARCHAR(150) NOT NULL, " +
            "  description  VARCHAR(1000), " +
            "  prep_minutes INT  DEFAULT 0, " +
            "  cook_minutes INT  DEFAULT 0, " +
            "  servings     INT  DEFAULT 1, " +
            "  difficulty   VARCHAR(10)  DEFAULT 'easy', " +
            "  chef_id      INT  NOT NULL, " +
            "  created_at   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP, " +
            "  FOREIGN KEY (chef_id) REFERENCES chef(chef_id) " +
            ")");

        // ingredient (CASCADE delete keeps referential integrity) ----
        createTableIfAbsent(conn, "ingredient",
            "CREATE TABLE ingredient (" +
            "  ingredient_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, " +
            "  recipe_id     INT NOT NULL, " +
            "  item_name     VARCHAR(100) NOT NULL, " +
            "  quantity      VARCHAR(50), " +
            "  unit          VARCHAR(30), " +
            "  FOREIGN KEY (recipe_id) REFERENCES recipe(recipe_id) ON DELETE CASCADE " +
            ")");

        // cuisine_tag ------------------------------------------------
        createTableIfAbsent(conn, "cuisine_tag",
            "CREATE TABLE cuisine_tag (" +
            "  tag_id   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY, " +
            "  tag_name VARCHAR(50) NOT NULL UNIQUE " +
            ")");

        // recipe_tag (join table) ------------------------------------
        createTableIfAbsent(conn, "recipe_tag",
            "CREATE TABLE recipe_tag (" +
            "  recipe_id INT NOT NULL, " +
            "  tag_id    INT NOT NULL, " +
            "  PRIMARY KEY (recipe_id, tag_id), " +
            "  FOREIGN KEY (recipe_id) REFERENCES recipe(recipe_id) ON DELETE CASCADE, " +
            "  FOREIGN KEY (tag_id)    REFERENCES cuisine_tag(tag_id) " +
            ")");
    }

    /**
     * Executes the CREATE TABLE statement only if the table does not yet exist.
     * Uses DatabaseMetaData to check, so it is safe to run on every startup.
     */
    private void createTableIfAbsent(Connection conn, String tableName, String ddl)
            throws SQLException {
        DatabaseMetaData meta = conn.getMetaData();
        // Derby stores table names in UPPER CASE
        try (ResultSet rs = meta.getTables(null, null, tableName.toUpperCase(), new String[]{"TABLE"})) {
            if (!rs.next()) {
                try (Statement stmt = conn.createStatement()) {
                    stmt.execute(ddl);
                    System.out.println("[DBInitializer] Created table: " + tableName);
                }
            }
        }
    }

    // ---------------------------------------------------------------
    // Sample data
    // ---------------------------------------------------------------

    private void seedSampleData(Connection conn) throws SQLException {
        // Only insert if chef table is empty
        try (Statement check = conn.createStatement();
             ResultSet rs = check.executeQuery("SELECT COUNT(*) FROM chef")) {
            rs.next();
            if (rs.getInt(1) > 0) return;   // data already seeded
        }

        System.out.println("[DBInitializer] Seeding sample data...");

        // --- Insert demo chef ---
        int chefId = insertChef(conn, "admin", "admin", "Admin Chef", "admin@recipehub.com");

        // --- Insert sample recipes ---
        int r1 = insertRecipe(conn, chefId,
            "Spaghetti Bolognese",
            "Classic Italian pasta dish with a rich, slow-cooked meat sauce.",
            20, 40, 4, "medium");

        int r2 = insertRecipe(conn, chefId,
            "Avocado Toast",
            "Simple and nutritious breakfast with fresh avocado on toasted sourdough.",
            10, 5, 2, "easy");

        int r3 = insertRecipe(conn, chefId,
            "Chicken Tikka Masala",
            "Tender chicken pieces in a creamy, spiced tomato sauce. Serve with rice or naan.",
            30, 45, 4, "hard");

        // --- Insert ingredients ---
        Object[][] ings = {
            // Spaghetti Bolognese
            {r1, "Spaghetti",       "400", "g"},
            {r1, "Minced Beef",     "500", "g"},
            {r1, "Tomato Passata",  "400", "ml"},
            {r1, "Onion",           "1",   "large"},
            {r1, "Garlic Cloves",   "3",   ""},
            {r1, "Olive Oil",       "2",   "tbsp"},
            // Avocado Toast
            {r2, "Avocado",         "2",   ""},
            {r2, "Sourdough Bread", "2",   "slices"},
            {r2, "Lemon Juice",     "1",   "tsp"},
            {r2, "Chilli Flakes",   "1",   "pinch"},
            // Chicken Tikka Masala
            {r3, "Chicken Breast",  "600", "g"},
            {r3, "Tikka Masala Paste", "3", "tbsp"},
            {r3, "Double Cream",    "200", "ml"},
            {r3, "Tinned Tomatoes", "400", "g"},
            {r3, "Garam Masala",    "1",   "tsp"},
        };

        String ingSQL = "INSERT INTO ingredient (recipe_id, item_name, quantity, unit) " +
                        "VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(ingSQL)) {
            for (Object[] row : ings) {
                ps.setInt   (1, (int)    row[0]);
                ps.setString(2, (String) row[1]);
                ps.setString(3, (String) row[2]);
                ps.setString(4, (String) row[3]);
                ps.addBatch();
            }
            ps.executeBatch();
        }

        // --- Insert cuisine tags ---
        String tagSQL = "INSERT INTO cuisine_tag (tag_name) VALUES (?)";
        String[] tags = {"Italian", "Breakfast", "Indian", "Vegetarian", "Quick"};
        try (PreparedStatement ps = conn.prepareStatement(tagSQL)) {
            for (String tag : tags) {
                ps.setString(1, tag);
                ps.addBatch();
            }
            ps.executeBatch();
        }

        System.out.println("[DBInitializer] Sample data inserted successfully.");
    }

    // --- Helpers ---

    private int insertChef(Connection conn, String username, String password,
                           String displayName, String email) throws SQLException {
        String sql = "INSERT INTO chef (username, password_hash, display_name, email) " +
                     "VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, username);
            ps.setString(2, ChefDAO.hashPassword(password));
            ps.setString(3, displayName);
            ps.setString(4, email);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            keys.next();
            return keys.getInt(1);
        }
    }

    private int insertRecipe(Connection conn, int chefId,
                             String title, String description,
                             int prepMin, int cookMin, int servings,
                             String difficulty) throws SQLException {
        String sql = "INSERT INTO recipe " +
                     "(title, description, prep_minutes, cook_minutes, servings, difficulty, chef_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, title);
            ps.setString(2, description);
            ps.setInt   (3, prepMin);
            ps.setInt   (4, cookMin);
            ps.setInt   (5, servings);
            ps.setString(6, difficulty);
            ps.setInt   (7, chefId);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            keys.next();
            return keys.getInt(1);
        }
    }
}

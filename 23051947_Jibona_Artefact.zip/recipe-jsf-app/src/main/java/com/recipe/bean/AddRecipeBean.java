package com.recipe.bean;

import com.recipe.dao.IngredientDAO;
import com.recipe.dao.RecipeDAO;
import com.recipe.dao.TagDAO;
import com.recipe.model.Ingredient;
import com.recipe.model.Recipe;
import com.recipe.model.Tag;
import jakarta.annotation.PostConstruct;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * ViewScoped JavaBean that manages the "Add Recipe" form.
 *
 * Scope: @ViewScoped – the bean survives multiple Ajax round-trips on the same page.
 * This is essential for the ingredient management: the user can add/remove
 * ingredients via Ajax without losing the recipe title/description they've typed.
 *
 * JSF features demonstrated:
 *  - @ViewScoped with @Inject (CDI)
 *  - Ajax partial-form processing (ingredient add/remove)
 *  - h:selectOneMenu (difficulty drop-down)
 *  - Bean-side validation in saveRecipe()
 */
@Named
@ViewScoped
public class AddRecipeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // ---- Bound to the main recipe form fields ----
    private Recipe recipe = new Recipe();

    // ---- Ingredient staging list (maintained across Ajax calls) ----
    private List<Ingredient> ingredientList = new ArrayList<>();

    // ---- Temporary inputs for the "add ingredient" row ----
    private String newIngName;
    private String newIngQty;
    private String newIngUnit;

    private String errorMessage;

    private final RecipeDAO     recipeDAO     = new RecipeDAO();
    private final IngredientDAO ingredientDAO = new IngredientDAO();
    private final TagDAO        tagDAO        = new TagDAO();

    private List<Tag>    availableTags;
    private List<String> selectedTagIds = new java.util.ArrayList<>();

    @PostConstruct
    public void init() {
        availableTags = tagDAO.getAllTags();
    }

    /**
     * CDI injection of the session-scoped LoginBean so we can check
     * who is logged in and set the chef_id on the new recipe.
     */
    @Inject
    private LoginBean loginBean;

    // ---------------------------------------------------------------
    // Action Methods
    // ---------------------------------------------------------------

    /**
     * Saves the recipe + staged ingredients to the database.
     * Returns a redirect outcome to the new recipe's detail page on success.
     *
     * Note: JSF-level required="" constraints are intentionally NOT used
     * on the form fields so that the "Add Ingredient" Ajax button can fire
     * without triggering required-field validation on the recipe title etc.
     * Validation is done here in the action method instead.
     */
    public String saveRecipe() {
        errorMessage = null;

        if (!loginBean.isLoggedIn()) {
            return "/login.xhtml?faces-redirect=true";
        }

        // Manual validation (avoids JSF required= conflicts with Ajax)
        if (recipe.getTitle() == null || recipe.getTitle().trim().isEmpty()) {
            errorMessage = "Recipe title is required.";
            return null;
        }
        if (recipe.getDifficulty() == null || recipe.getDifficulty().isEmpty()) {
            recipe.setDifficulty("easy");
        }

        recipe.setTitle(recipe.getTitle().trim());
        recipe.setChefId(loginBean.getLoggedInChef().getChefId());

        boolean saved = recipeDAO.addRecipe(recipe);
        if (!saved) {
            errorMessage = "Failed to save the recipe. Please try again.";
            return null;
        }

        // Persist each staged ingredient
        for (Ingredient ing : ingredientList) {
            ing.setRecipeId(recipe.getRecipeId());
            ingredientDAO.addIngredient(ing);
        }

        // Save selected tags
        tagDAO.setTagsForRecipe(recipe.getRecipeId(), selectedTagIds);

        // Redirect to the newly created recipe's detail page
        return "/recipe-detail.xhtml?faces-redirect=true&recipeId=" + recipe.getRecipeId();
    }

    /**
     * Ajax action: adds the ingredient in the temporary input fields
     * to the staging list and clears those inputs.
     * Called by the "Add" button with f:ajax execute="@form" render="ingredientPanel".
     */
    public void addIngredientToList() {
        if (newIngName != null && !newIngName.trim().isEmpty()) {
            Ingredient ing = new Ingredient();
            ing.setItemName(newIngName.trim());
            ing.setQuantity(newIngQty  != null ? newIngQty.trim()  : "");
            ing.setUnit    (newIngUnit != null ? newIngUnit.trim() : "");
            ingredientList.add(ing);
            // Clear the temporary inputs ready for the next ingredient
            newIngName = "";
            newIngQty  = "";
            newIngUnit = "";
        }
    }

    /**
     * Ajax action: removes the ingredient at the given index from the staging list.
     * Called by the "Remove" button inside ui:repeat with varStatus.index.
     */
    public void removeIngredient(int index) {
        if (index >= 0 && index < ingredientList.size()) {
            ingredientList.remove(index);
        }
    }

    // ---------------------------------------------------------------
    // Getters / Setters
    // ---------------------------------------------------------------

    public Recipe           getRecipe()             { return recipe; }
    public void             setRecipe(Recipe v)     { this.recipe = v; }

    public List<Ingredient> getIngredientList()     { return ingredientList; }

    public String getNewIngName()               { return newIngName; }
    public void   setNewIngName(String v)       { this.newIngName = v; }

    public String getNewIngQty()                { return newIngQty; }
    public void   setNewIngQty(String v)        { this.newIngQty = v; }

    public String getNewIngUnit()               { return newIngUnit; }
    public void   setNewIngUnit(String v)       { this.newIngUnit = v; }

    public List<Tag>    getAvailableTags()          { return availableTags; }
    public List<String> getSelectedTagIds()          { return selectedTagIds; }
    public void         setSelectedTagIds(List<String> v) { this.selectedTagIds = v; }

    public String getErrorMessage()             { return errorMessage; }
}

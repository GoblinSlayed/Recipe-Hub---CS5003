package com.recipe.bean;

import com.recipe.dao.ChefDAO;
import com.recipe.model.Chef;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import java.io.Serializable;

/**
 * SessionScoped JavaBean that manages the logged-in user for the whole browser session.
 *
 * Scope: @SessionScoped  – one instance per HTTP session.
 * @Named makes it accessible in EL expressions as #{loginBean}.
 */
@Named
@SessionScoped
public class LoginBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // Fields bound to login.xhtml form inputs
    private String username;
    private String password;

    // Null means nobody is logged in
    private Chef loggedInChef;

    private String errorMessage;

    private final ChefDAO chefDAO = new ChefDAO();

    // ---------------------------------------------------------------
    // Action Methods (called by JSF command buttons/links)
    // ---------------------------------------------------------------

    /**
     * Validates the credentials.
     * Returns "login-success" (handled by faces-config.xml) on success,
     * or null to stay on the login page with an error message.
     */
    public String login() {
        errorMessage = null;
        Chef chef = chefDAO.findByCredentials(username, password);
        if (chef != null) {
            loggedInChef = chef;
            password = null;          // don't keep plain-text password in session
            return "login-success";   // → navigation rule → /recipes.xhtml (redirect)
        }
        errorMessage = "Invalid username or password. Please try again.";
        return null;                  // stay on login page
    }

    /**
     * Logs the user out by invalidating the HTTP session and redirecting to the home page.
     */
    public String logout() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "/index.xhtml?faces-redirect=true";
    }

    // ---------------------------------------------------------------
    // Helper Properties (used in the Facelets template)
    // ---------------------------------------------------------------

    /** True when a chef is currently logged in. */
    public boolean isLoggedIn() {
        return loggedInChef != null;
    }

    /** True only when the logged-in user is the admin account. */
    public boolean isAdmin() {
        return loggedInChef != null && "admin".equals(loggedInChef.getUsername());
    }

    /**
     * Null-safe display name used in the navbar.
     * #{loginBean.displayName} never throws NPE.
     */
    public String getDisplayName() {
        return loggedInChef != null ? loggedInChef.getDisplayName() : "";
    }

    // ---------------------------------------------------------------
    // Standard Getters / Setters
    // ---------------------------------------------------------------

    public String getUsername()          { return username; }
    public void   setUsername(String v)  { this.username = v; }

    public String getPassword()          { return password; }
    public void   setPassword(String v)  { this.password = v; }

    public Chef   getLoggedInChef()      { return loggedInChef; }

    public String getErrorMessage()           { return errorMessage; }
    public void   setErrorMessage(String v)   { this.errorMessage = v; }
}

package com.recipe.bean;

import com.recipe.dao.IngredientDAO;
import com.recipe.dao.RecipeDAO;
import com.recipe.dao.TagDAO;
import com.recipe.model.Ingredient;
import com.recipe.model.Recipe;
import com.recipe.model.Tag;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * ViewScoped bean that backs the Edit Recipe page.
 *
 * The recipe ID is passed via f:viewParam (?recipeId=N).
 * On load, the existing recipe and its ingredients are fetched from the DB
 * and used to pre-populate the form.
 *
 * On save, the recipe fields are updated via RecipeDAO.updateRecipe(),
 * and the ingredient list is replaced (delete all + re-insert).
 *
 * Only the recipe owner or admin can save changes.
 */
@Named
@ViewScoped
public class EditRecipeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // Bound by f:viewParam
    private int recipeId;

    // Loaded from DB and bound to the form fields
    private Recipe recipe;

    // Ingredient staging list – initialised from DB, editable via Ajax
    private List<Ingredient> ingredientList = new ArrayList<>();

    // Temporary inputs for the Add Ingredient row
    private String newIngName;
    private String newIngQty;
    private String newIngUnit;

    private String errorMessage;

    private final RecipeDAO     recipeDAO     = new RecipeDAO();
    private final IngredientDAO ingredientDAO = new IngredientDAO();
    private final TagDAO        tagDAO        = new TagDAO();

    private List<Tag>    availableTags;
    private List<String> selectedTagIds = new java.util.ArrayList<>();

    @Inject
    private LoginBean loginBean;

    // ---------------------------------------------------------------
    // Called by f:viewAction on page load
    // ---------------------------------------------------------------

    public void loadRecipe() {
        if (recipeId > 0) {
            recipe = recipeDAO.getRecipeById(recipeId);
            if (recipe != null) {
                ingredientList = ingredientDAO.getByRecipeId(recipeId);
                availableTags  = tagDAO.getAllTags();
                // Pre-select tags already on this recipe
                List<Tag> currentTags = tagDAO.getTagsByRecipeId(recipeId);
                selectedTagIds = new java.util.ArrayList<>();
                for (Tag t : currentTags) {
                    selectedTagIds.add(String.valueOf(t.getTagId()));
                }
            }
        }
    }

    // ---------------------------------------------------------------
    // Action Methods
    // ---------------------------------------------------------------

    /**
     * Saves the edited recipe back to the database.
     * Updates the recipe row and replaces all ingredients.
     */
    public String saveEdit() {
        errorMessage = null;

        if (!loginBean.isLoggedIn() || recipe == null) {
            return "/login.xhtml?faces-redirect=true";
        }

        // Ownership check
        boolean isOwner = recipe.getChefId() == loginBean.getLoggedInChef().getChefId();
        if (!isOwner && !loginBean.isAdmin()) {
            errorMessage = "You do not have permission to edit this recipe.";
            return null;
        }

        if (recipe.getTitle() == null || recipe.getTitle().trim().isEmpty()) {
            errorMessage = "Recipe title is required.";
            return null;
        }
        recipe.setTitle(recipe.getTitle().trim());

        // Update the recipe row
        boolean updated = recipeDAO.updateRecipe(recipe);
        if (!updated) {
            errorMessage = "Failed to update the recipe. Please try again.";
            return null;
        }

        // Replace ingredients
        ingredientDAO.deleteByRecipeId(recipeId);
        for (Ingredient ing : ingredientList) {
            ing.setRecipeId(recipeId);
            ingredientDAO.addIngredient(ing);
        }

        // Replace tags
        tagDAO.setTagsForRecipe(recipeId, selectedTagIds);

        // Redirect to the updated recipe detail page
        return "/recipe-detail.xhtml?faces-redirect=true&recipeId=" + recipeId;
    }

    /** Ajax: adds a new ingredient to the staging list. */
    public void addIngredientToList() {
        if (newIngName != null && !newIngName.trim().isEmpty()) {
            Ingredient ing = new Ingredient();
            ing.setItemName(newIngName.trim());
            ing.setQuantity(newIngQty  != null ? newIngQty.trim()  : "");
            ing.setUnit    (newIngUnit != null ? newIngUnit.trim() : "");
            ingredientList.add(ing);
            newIngName = "";
            newIngQty  = "";
            newIngUnit = "";
        }
    }

    /** Ajax: removes ingredient at the given index. */
    public void removeIngredient(int index) {
        if (index >= 0 && index < ingredientList.size()) {
            ingredientList.remove(index);
        }
    }

    // ---------------------------------------------------------------
    // Getters / Setters
    // ---------------------------------------------------------------

    public int    getRecipeId()        { return recipeId; }
    public void   setRecipeId(int v)   { this.recipeId = v; }

    public Recipe getRecipe()          { return recipe; }
    public void   setRecipe(Recipe v)  { this.recipe = v; }

    public List<Ingredient> getIngredientList() { return ingredientList; }

    public String getNewIngName()              { return newIngName; }
    public void   setNewIngName(String v)      { this.newIngName = v; }

    public String getNewIngQty()               { return newIngQty; }
    public void   setNewIngQty(String v)       { this.newIngQty = v; }

    public String getNewIngUnit()              { return newIngUnit; }
    public void   setNewIngUnit(String v)      { this.newIngUnit = v; }

    public List<Tag>    getAvailableTags()              { return availableTags; }
    public List<String> getSelectedTagIds()              { return selectedTagIds; }
    public void         setSelectedTagIds(List<String> v){ this.selectedTagIds = v; }

    public String getErrorMessage()            { return errorMessage; }
}

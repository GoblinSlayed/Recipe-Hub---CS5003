package com.recipe.bean;

import com.recipe.dao.ChefDAO;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import java.io.Serializable;

/**
 * RequestScoped JavaBean that handles the user-registration form.
 *
 * Scope: @RequestScoped – a fresh instance is created for each HTTP request.
 * Action method returns "register-success" on success (→ faces-config.xml redirects to login).
 */
@Named
@RequestScoped
public class RegisterBean implements Serializable {

    private static final long serialVersionUID = 1L;

    // Bound to register.xhtml form inputs
    private String username;
    private String password;
    private String confirmPassword;
    private String displayName;
    private String email;

    private String errorMessage;

    private final ChefDAO chefDAO = new ChefDAO();

    // ---------------------------------------------------------------
    // Action Method
    // ---------------------------------------------------------------

    /**
     * Validates the form, then inserts a new chef row.
     * Returns "register-success" on success (handled by faces-config.xml),
     * or null to stay on the page with an error.
     */
    public String register() {
        errorMessage = null;

        // Basic presence checks
        if (username == null || username.trim().isEmpty()) {
            errorMessage = "Username is required.";
            return null;
        }
        if (password == null || password.trim().isEmpty()) {
            errorMessage = "Password is required.";
            return null;
        }

        // Password confirmation check
        if (!password.equals(confirmPassword)) {
            errorMessage = "Passwords do not match.";
            return null;
        }

        // Minimum password length
        if (password.length() < 6) {
            errorMessage = "Password must be at least 6 characters.";
            return null;
        }

        // Unique username check
        if (chefDAO.usernameExists(username.trim())) {
            errorMessage = "That username is already taken. Please choose another.";
            return null;
        }

        // Insert into DB
        boolean ok = chefDAO.register(
            username.trim(),
            password,
            displayName != null ? displayName.trim() : username.trim(),
            email != null ? email.trim() : ""
        );

        if (ok) {
            return "register-success";  // → faces-config.xml → /login.xhtml (redirect)
        }

        errorMessage = "Registration failed due to a database error. Please try again.";
        return null;
    }

    // ---------------------------------------------------------------
    // Getters / Setters
    // ---------------------------------------------------------------

    public String getUsername()               { return username; }
    public void   setUsername(String v)       { this.username = v; }

    public String getPassword()               { return password; }
    public void   setPassword(String v)       { this.password = v; }

    public String getConfirmPassword()             { return confirmPassword; }
    public void   setConfirmPassword(String v)     { this.confirmPassword = v; }

    public String getDisplayName()            { return displayName; }
    public void   setDisplayName(String v)    { this.displayName = v; }

    public String getEmail()                  { return email; }
    public void   setEmail(String v)          { this.email = v; }

    public String getErrorMessage()           { return errorMessage; }
}

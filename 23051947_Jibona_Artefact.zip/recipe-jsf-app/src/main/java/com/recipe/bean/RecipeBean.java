package com.recipe.bean;

import com.recipe.dao.RecipeDAO;
import com.recipe.dao.TagDAO;
import com.recipe.model.Recipe;
import com.recipe.model.Tag;

import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

/**
 * ViewScoped JavaBean that powers both the home page (index.xhtml)
 * and the browse page (recipes.xhtml).
 *
 * Scope: @ViewScoped (javax.faces.view.ViewScoped) – the bean lives as long
 *        as the user stays on the same JSF view, which allows Ajax calls
 *        (like the live search) to update the same bean instance.
 *
 * JSF features demonstrated:
 *  - @PostConstruct   : loads all recipes when the page first renders
 *  - Ajax listener    : search() is called by f:ajax on keyup events
 */
@Named
@ViewScoped
public class RecipeBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private String       searchQuery = "";
    private List<Recipe> recipes;
    private List<Tag>    allTags;
    private int          selectedFilterTagId = 0;

    private final RecipeDAO recipeDAO = new RecipeDAO();
    private final TagDAO    tagDAO    = new TagDAO();

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------

    /**
     * Runs once after the bean is created and injected.
     * Pre-loads all recipes so the page is populated immediately.
     */
    @PostConstruct
    public void init() {
        recipes = recipeDAO.getAllRecipes();
        allTags = tagDAO.getAllTags();
    }

    // ---------------------------------------------------------------
    // Ajax Listener
    // ---------------------------------------------------------------

    /**
     * Called by f:ajax listener="#{recipeBean.search}" on every keyup in the search box.
     * Re-queries the database and updates the recipes list, which is then
     * re-rendered in the browser without a full page reload.
     */
    public void search() {
        selectedFilterTagId = 0;  // reset tag filter when searching
        String q = (searchQuery != null) ? searchQuery.trim() : "";
        recipes = recipeDAO.searchRecipes(q);
    }

    /** Ajax listener: filters recipes by the selected tag. */
    public void filterByTag() {
        searchQuery = "";
        if (selectedFilterTagId == 0) {
            recipes = recipeDAO.getAllRecipes();
        } else {
            recipes = recipeDAO.getRecipesByTagId(selectedFilterTagId);
        }
    }

    // ---------------------------------------------------------------
    // Getters / Setters
    // ---------------------------------------------------------------

    public String       getSearchQuery()           { return searchQuery; }
    public void         setSearchQuery(String v)   { this.searchQuery = v; }

    public List<Recipe> getRecipes()               { return recipes; }
    public List<Tag>    getAllTags()                { return allTags; }
    public int          getSelectedFilterTagId()   { return selectedFilterTagId; }
    public void         setSelectedFilterTagId(int v) { this.selectedFilterTagId = v; }
}

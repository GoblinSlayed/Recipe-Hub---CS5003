package com.recipe.bean;

import com.recipe.dao.IngredientDAO;
import com.recipe.dao.RecipeDAO;
import com.recipe.dao.TagDAO;
import com.recipe.model.Recipe;
import com.recipe.model.Tag;
import java.util.List;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;

/**
 * RequestScoped JavaBean that loads a single recipe for the detail page.
 *
 * The recipe ID is passed as a URL query parameter (?recipeId=N) and bound
 * to this bean via f:viewParam in recipe-detail.xhtml.  The f:event viewAction
 * then calls loadRecipe() before the page renders.
 *
 * JSF features demonstrated:
 *  - f:viewParam  : binds URL parameter to a bean property
 *  - f:event type="viewAction" : triggers data loading before render response
 */
@Named
@ViewScoped
public class RecipeDetailBean implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Set by f:viewParam name="recipeId" */
    private int recipeId;

    /** Loaded by loadRecipe(); null if the ID is invalid. */
    private Recipe recipe;

    private final RecipeDAO     recipeDAO     = new RecipeDAO();
    private final IngredientDAO ingredientDAO = new IngredientDAO();
    private final TagDAO        tagDAO        = new TagDAO();
    private List<Tag>           recipeTags;

    @Inject
    private LoginBean loginBean;

    // ---------------------------------------------------------------
    // Called by f:event type="viewAction" in the XHTML
    // ---------------------------------------------------------------

    /**
     * Fetches the recipe and its ingredients from the database.
     * If recipeId is 0 or invalid, recipe remains null and the page
     * shows a "Recipe not found" message.
     */
    public void loadRecipe() {
        if (recipeId > 0) {
            recipe = recipeDAO.getRecipeById(recipeId);
            if (recipe != null) {
                recipe.setIngredients(ingredientDAO.getByRecipeId(recipeId));
                recipeTags = tagDAO.getTagsByRecipeId(recipeId);
            }
        }
    }

    /**
     * Deletes the current recipe.
     * Owner can delete their own; admin can delete any.
     * Ingredients are removed automatically via ON DELETE CASCADE.
     */
    public String deleteRecipe() {
        if (!loginBean.isLoggedIn() || recipe == null) {
            return "/recipes.xhtml?faces-redirect=true";
        }
        if (loginBean.isAdmin()) {
            recipeDAO.deleteRecipeById(recipeId);
        } else if (recipe.getChefId() == loginBean.getLoggedInChef().getChefId()) {
            recipeDAO.deleteRecipe(recipeId, loginBean.getLoggedInChef().getChefId());
        }
        return "/recipes.xhtml?faces-redirect=true";
    }

    // ---------------------------------------------------------------
    // Getters / Setters
    // ---------------------------------------------------------------

    public int       getRecipeId()        { return recipeId; }
    public void      setRecipeId(int v)   { this.recipeId = v; }

    public Recipe    getRecipe()          { return recipe; }
    public List<Tag> getRecipeTags()      { return recipeTags; }
}

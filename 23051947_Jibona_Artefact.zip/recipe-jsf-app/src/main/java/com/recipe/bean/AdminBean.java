package com.recipe.bean;

import com.recipe.dao.ChefDAO;
import com.recipe.model.Chef;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

/**
 * RequestScoped bean that backs the admin panel page.
 * Only accessible when loginBean.admin is true.
 */
@Named
@RequestScoped
public class AdminBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<Chef> chefs;

    private final ChefDAO chefDAO = new ChefDAO();

    @Inject
    private LoginBean loginBean;

    @PostConstruct
    public void init() {
        if (loginBean.isAdmin()) {
            chefs = chefDAO.getAllChefs();
        }
    }

    public List<Chef> getChefs() { return chefs; }
}
